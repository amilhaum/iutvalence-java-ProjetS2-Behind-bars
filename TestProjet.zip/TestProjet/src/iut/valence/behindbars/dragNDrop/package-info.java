/**
 * 
 */
/**
 * @author montcare
 *
 */
package iut.valence.behindbars.dragNDrop;