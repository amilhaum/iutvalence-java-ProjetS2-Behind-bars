package iut.valence.behindbars.windows;

public class PositionOnScreen
{
	private int	x;
	private int	y;

	public PositionOnScreen(int x0, int y0)
	{
		this.x = x0;
		this.y = y0;
	}

	public int getX()
	{
		return x;
	}

	public void setX(int x)
	{
		this.x = x;
	}

	public int getY()
	{
		return y;
	}

	public void setY(int y)
	{
		this.y = y;
	}

}
