package iut.valence.behindbars.windows;

import javax.swing.JFrame;

public class BehindBars
{

	public static void main(String[] args)
	{
		JFrame windows = new MainWindows();
	}
}
