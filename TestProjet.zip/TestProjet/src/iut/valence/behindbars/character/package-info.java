/**
 * 
 */
/**
 * @author  Nicolas Jourdan
 *
 */
package iut.valence.behindbars.character;
