package Tests;
//package iut.valence.behindbars.game;
//
//
//import java.util.ArrayList;
//
//import junit.framework.*;
//import iut.valence.behindbars.character.Character;
//import iut.valence.behindbars.character.NPC;
//import iut.valence.behindbars.character.StateOfCharacter;
//
//
//
//public class Test_getNPCinList extends TestCase { 
//
//
//
//public Test_getNPCinList (String Character) 
//	{
//		super (Character);
//	}
//	 
//public void testgetNPCinList()
//	{
//		Game mygame= new Game ("Joueur_Test");
//		ArrayList<Character> charactersInCells = new ArrayList<Character>();
//		charactersInCells.add(NPCs.get("Barry"));
//		charactersInCells.add(NPCs.get("Garry"));
//		charactersInCells.add(NPCs.get("Brad"));
//		charactersInCells.add(NPCs.get("Bryan"));
//		charactersInCells.add(NPCs.get("Steven"));
//		fail(Game.getNPCinList("Barry", charactersInCells));
//		//assertNotNull(new NPC("Garry", StateOfCharacter.Prisoner));
//		//assertNotNull(new NPC("Bart", StateOfCharacter.Prisoner));
//		}  
//
//public static Test suite()
//	{
//	TestSuite suite = new TestSuite();
//	suite.addTest(new Test_getNPCinList ("testgetNPCinList"));
//	return (Test) suite;
//	}
//}
