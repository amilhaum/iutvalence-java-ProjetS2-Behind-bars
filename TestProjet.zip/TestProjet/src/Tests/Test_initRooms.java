package Tests;
//package iut.valence.behindbars.game;
//
//import static org.junit.Assert.*;
//
//import java.util.ArrayList;
//
//import org.junit.Test;
//
//import junit.framework.TestCase;
//import junit.framework.TestSuite;
//import iut.valence.behindbars.character.Character;
//import iut.valence.behindbars.character.NPC;
//import iut.valence.behindbars.character.StateOfCharacter;
//	
//public class Test_initRooms extends TestCase {
//	 
//	public Test_initRooms (String Character) 
//	{
//		super (Character);
//	} 
//
//	@Test
//	public void testinitroom(){
//		assertNotNull(new Room("cells","Barry","Infirmary's key"));
//		assertNotNull(new Room("breakRoom","Daryl","Knife"));
//		assertNull(new Room("outside", "Carlos"));
//	}
//	
//	public static Test suite()
//	{
//	TestSuite suite = new TestSuite();
//	suite.addTest(new Test_initRooms ("testinitrooms"));
//	return (Test) suite;
//	}
//}
//
//
//
//
